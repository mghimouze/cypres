# Cypress Studio

[Let's head over to the documentation][docs] to explore Cypress Studio for a moment.

[docs]: https://docs.cypress.io/guides/core-concepts/cypress-studio

We'll add the following to our `cypress.json`.

```js
{
  "experimentalStudio": true
}
```

Now, let's head into `cypress/integration/14-cypress-studio.spec.js` and auto generate some tests.
