# Basic Practice (Exercise)

In `cypress/integration/02-basic-practice.spec.js`, we have some empty tests that are ready to go.

These tests cover the a few of the core features of our silly little application.

- Adding a new item
- Filtering the items on the page
- Removing all of the items from the page
- Removing an item from the page
- Marking all of the items as unpacked
- Marking an individual item as packed

See how many of them you can get through and then we'll go over them together.
