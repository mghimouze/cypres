# File Uploads and Downloads

This is an area for you to explore after the workshop.

**Plugin**: https://github.com/abramenal/cypress-file-upload

**File download recipe**: https://github.com/cypress-io/cypress-example-recipes/tree/master/examples/testing-dom__download
