/// <reference types="@sveltejs/kit" />

type Item = {
  id: number;
  title: string;
  packed: boolean;
};
