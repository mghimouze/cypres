export const focusOnMount = (node: HTMLElement) => {
  node.focus();
};
