let current = 0;

export const getId = () => ++current;
