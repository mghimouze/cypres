type DogFact = {
  id: number;
  fact: string;
};
