<script context="module">
  export const ssr = false;
</script>

<svelte:head>
  <title>Jetsetter - Cypress, Frontend Masters</title>
</svelte:head>

<div id="jetsetter-application">
  <slot />
</div>
